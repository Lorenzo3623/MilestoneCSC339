package com.gcu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Topice22ApplicationTests {

	@Test
	void contextLoads() {
	}

}
